<?php
session_start();
##include('c_tools.php');

$terrain=$_POST["terrain"];
$type=$_POST['type'];;
$inscrit=(int)$_POST["inscrit"];
$serie=$_POST["serie"];
$elite=(int)$_POST["elite"];

$_SESSION['terrain']=$terrain;
$_SESSION['type']=$type;
$_SESSION['inscrit']=$inscrit;
$_SESSION['serie']=$serie;
if  ($elite < 2) { $elite=0; }
$_SESSION['elite']=$elite;


# ceci est un commentaire
# ajouter ici le nombre de joueur par terrain


$tab=[]; # pour l'affichage en mode tableau
$tabj=[]; # pour l'affichage en mode tableau
$alpi=[];
$arefaire=1;

function reset_array ( &$ar, $nb, $v)
{
		$l=0;
		while ( $l < $nb ) {
			$ar[$l]=$v;
			$l++;
		}
}

function pick_player($alreadypicked, $modulo)
{
	while (true) {
		$nextplayer=rand() % $modulo;	
		if ($alreadypicked[$nextplayer] == 1) {
			continue;
		}
		break;
	}
	return  $nextplayer;
}

$min_joueur=$terrain*$type;

if ( $min_joueur <= $inscrit ) {

	$z=0;
	while ( $z < 1000  && $arefaire == 1 ) {

		$arefaire=0;

		# préparation du tableau
		# mise à jour de l'entête
		#
		$tab[0][0]="Série/Terrain";
		$i=0;
		while ( $i < $terrain ) {
			$tab[0][$i+1]="Terrain ".$i+1;
			$i++;
		}
		
		reset_array($alpi, $inscrit, 0);


		$m=0;
		$nbp=0;
		$nbj=[];
		reset_array($nbj, $inscrit, 0);
		$mess="";
		#$r="";
		$db=0;
		while ($m < $serie) {
			#$r=$r."Série : ". $m+1 . "  ================ <br>";
			$tab[$m+1][0]="Série ".$m+1;
			$t=0;
			$k=0;
			$jou=[];
			reset_array($jou, $inscrit, -1);
			while ( $t < $terrain) {
				$j=0;
				while ( $j < $type) {
					while (true) {
						if ( $nbp == $inscrit ) {
							$nbp=0;
							reset_array( $alpi, $inscrit, 0);
						}
						$p=pick_player($alpi, $inscrit);
						
						$ok=1;
						$i=0;
						# déjà choisi dans la même série ?
						while ( $i < $k ) {
							if ( $jou[$i] == $p ) {
								$ok=0;
								break;
							} else {
								$i++;
							}
						}
						if ( $ok == 1 ) {
							# pas encore choisi
							# if type = 4, on évite que les élites jouent ensemble
							if ($type == 4 && $elite > 0 && $j%2 == 1 && $jou[$k-1] < $elite && $p < $elite ) {
								$arefaire=1;
							}
							$jou[$k]=$p;
							$alpi[$p]=1;
							$nbp++;
							$nbj[$p]=$nbj[$p]+1;
							break;
						}
					}
					$j++;
					$k++;
				}
				if ( $type == 2) {
					#$r=$r . "Terrain " . $t+1 . " : J" . $jou[$t*2]+1 . " vs J" . $jou[$t*2+1]+1 . " <br>";
					$tab[$m+1][2*$t+1]=$jou[$t*2]+1;
					$tab[$m+1][2*$t+2]=$jou[$t*2+1]+1;
				} else {
					#$r=$r . "Terrain " . $t+1 . " : J" . $jou[$t*4]+1 . " - J" . $jou[$t*4+1]+1 . " vs J" . $jou[$t*4+2]+1 . " - J" . $jou[$t*4+3]+1 . " <br>";
					$tab[$m+1][4*$t+1]=$jou[$t*4]+1;
					$tab[$m+1][4*$t+2]=$jou[$t*4+1]+1;
					$tab[$m+1][4*$t+3]=$jou[$t*4+2]+1;
					$tab[$m+1][4*$t+4]=$jou[$t*4+3]+1;
				}
				# On vient de finir de remplir un terrain
				# Si on est dans la dernière série et que le nombre d'inscrit est atteint sur un terrain complet, on peut arrêter.
				#
				if (($m+1 == $serie) &&  ($nbp == $inscrit)) {
					# on arrête la série
					break;
				}
				$t++;
			}
			$m++;
		}



		#$_SESSION['message']="terrain =" . $terrain . " inscrit =" . $inscrit . " serie = " . $serie . " type = " . $type . " debug= " . $db . " <br><br> " ;
		if ( $arefaire == 0) {
			if ( $elite !=0 && $type == 4 ) {
				$msg=", les ".$elite." premiers joueurs ne sont jamais dans la même équipe.";
			} else {
				$msg=".";
			}
			$_SESSION['message']="Matchs générés avec succès, algorithme choisi pour une attente minimale".$msg;
			$_SESSION['statut']="success";
		} else {
			$_SESSION['message']="Au moins deux élites sont ensembles, relancez si nécessaire";
			$_SESSION['statut']="error";
		}
		#$_SESSION['match']=$r;
		$i=0;
		$r="";
		while ($i < $inscrit) {
			$r=$r . "Joueur J" . $i+1 . " = " . $nbj[$i] . "<br>";	
			$tabj[$i][0]="Joueur J".$i+1;
			$tabj[$i][1]=$nbj[$i];
			$i++;
		}
		$_SESSION['joueur']=$r;
		$z++;
	}
}
else {
	$_SESSION['message']="Nombre d'inscrits insuffisants";
	$_SESSION['match']="";
	$_SESSION['joueur']="";
}
$_SESSION['tab']=$tab;
$_SESSION['tabj']=$tabj;
header('Location: ../index.php');
