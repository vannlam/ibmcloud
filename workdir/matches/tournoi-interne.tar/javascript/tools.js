// Source - https://stackoverflow.com/a/55743302
// Posted by Niente0, modified by community. See post 'Timeline' for change history
// Retrieved 2026-06-18, License - CC BY-SA 4.0

function copytable(el) {
  var urlField = document.getElementById(el)
  var range = document.createRange()
  range.selectNode(urlField)
  window.getSelection().addRange(range)
  document.execCommand('copy')
  alert('Tableau copié dans le presse-papier. Attention le format de ce tableau est conservé si le collage est dans googlesheet ou dans Numbers mais pas dans Excel.')
}

  function confirmAction(question, evt) {
    if (!confirm(question)) {
      if (evt) {
        evt.preventDefault();
      }
      return false;
    }
    return true;
  }

