<?php
session_start();

if (isset($_SESSION['message'])) {
        $message = $_SESSION['message'];
} else {
        $message = "";
}

if (isset($_SESSION['match'])) {
        $match = $_SESSION['match'];
} else {
        $match = "";
}

if (isset($_SESSION['joueur'])) {
        $joueur = $_SESSION['joueur'];
} else {
        $joueur = 0;
}

if (isset($_SESSION['terrain'])) {
        $terrain = $_SESSION['terrain'];
} else {
        $terrain = 4;
}

if (isset($_SESSION['type'])) {
        $type = $_SESSION['type'];
} else {
        $type = 4;
}

if (isset($_SESSION['inscrit'])) {
        $inscrit = $_SESSION['inscrit'];
} else {
        $inscrit = 24;
}

if (isset($_SESSION['elite'])) {
        $elite = $_SESSION['elite'];
} else {
        $elite = 0;
}

if (isset($_SESSION['statut'])) {
        $statut = $_SESSION['statut'];
} else {
        $statut = "success";
}

if (isset($_SESSION['serie'])) {
        $serie = $_SESSION['serie'];
} else {
        $serie = 6;
}

if (isset($_SESSION['tab'])) {
	$askConfirmation = true;
        $tab = $_SESSION['tab'];
} else {
	$askConfirmation = false;
        $tab = [];
}

if (isset($_SESSION['tabj'])) {
        $tabj = $_SESSION['tabj'];
} else {
        $tabj = [];
}

// Check for previous session

?>
<!DOCTYPE html>

<html >
	<head>
		<title>Outil de génération de matchs pour les tournois internes</title>
		<meta charset=utf-8" content="width=device-width; initial-scale=1.0" />
    <link rel="stylesheet" href="dojo-release-1.17.3/dijit/themes/soria/soria.css">
    <link type="text/css" rel="stylesheet" href="includes/style.css" />
    <script src="dojo-release-1.17.3/dojo/dojo.js" data-dojo-config="isDebug: true, async: true, parseOnLoad: true"></script>
    <script type="text/javascript" src="javascript/tools.js"></script>
	</head>
	<body class="soria bgstd" >
	<?php
	$question = "Etes-vous sûr de vouloir regénérer la totalité du tableau des matchs ?";
	?>

	<form action="./controller/c_generate_matches.php" method="post" name="formlogin" >
			<fieldset>
				<legend>Outil de génération aléatoires des matchs. Copyright club de Badminton de L'Hay les roses </legend>
				<label for="terrain">Nombre de terrains :<span class="requis">*</span></label>
				<select name="terrain" id="terrain" >
				<?php
				$v=2;
				while ( $v < 11 ) {
					if ( $v == $terrain) {
						$s="selected";
					} else {
						$s="";
					}
					echo '<option value="'.$v.'"'.$s.'>'.$v.'</option>';
					$v++;
				}
				?>
				</select><br><br>
				<label for="type">Type de jeu :<span class="requis">*</span></label>
				<select name="type" id="type" >
				<?php
					if ( $type == 2) {
				?>
					<option value="2" selected >Simple</option>
					<option value="4" >Double</option>
				<?php
				}
				else {
				?>
					<option value="2">Simple</option>
					<option value="4" selected >Double</option>
				<?php
				}
				?>
				</select><br><br>
				<label for="inscrit">Nombre d'inscrits :<span class="requis">*</span></label>
				<input type="text" id="inscrit" name="inscrit" value=<?php echo $inscrit; ?> ><br><br>
				<label for="serie">Nombre de séries :<span class="requis">*</span></label>
				<select name="serie" id="serie" >
				<?php
				$v=2;
				while ( $v < 16 ) {
					if ( $v == $serie) {
						$s="selected";
					} else {
						$s="";
					}
					echo '<option value="'.$v.'"'.$s.'>'.$v.'</option>';
					$v++;
				}
				?>
				</select><br><br>
				<label for="elite">Nombre d'elites (optionnel) :</label>
				<input type="text" id="elite" name="elite" value=<?php echo $elite; ?> ><br><br>
				<button data-dojo-type="dijit/form/Button" type="submit"
				<?php if ($askConfirmation) { ?>
					data-dojo-props="onClick:function(evt){ return confirmAction('<?php echo addslashes($question); ?>', evt); }"
				<?php } ?>
				>Soumettre</button>
				<br><br>
				<span class="<?php echo $statut ?>"><?php echo $message ?></span>
				<?php
				if ( count($tab) > 0 ) {
				?>
					<fieldset>
						<button data-dojo-type="dijit/form/Button" onClick="copytable('matchs');" type="button">Copier le tableau</button>
						<br>
						<legend>Proposition de matchs</legend>
						<table id="matchs" style="width:100%">
						<?php
						$i=0;
						$c=count($tab);
						while ( $i < $c ) {
							echo "<tr>";
							$l=$tab[$i];
							$c1=count($l);
							$j=0;
							while ( $j < $c1 ) {
								if ( $i == 0 && $j > 0) {
									echo "<th colspan=".$type." style=vertical-align:middle:bold;>".$tab[$i][$j]." </th>";
								} else {
									if ( $j>0 ) {
										echo "<th ";
										if ( $type==4 && $tab[$i][$j] <= $elite) {
											echo " class=error ";
										}
										echo " >J".$tab[$i][$j]."</th>";
									} else {
										echo "<th>".$tab[$i][$j]."</th>";
									}
								}
								$j++;
							}
							echo "</tr>";
							if ( $i !=0 ) {
								echo "<tr>";
								echo "<th><strong>Score</strong></th>";
								$j=1;
								while ( $j < $c1 ) {
									if ( $type == 2 ) {
										echo "<th> </th>";
									} else {
										if ( $j%2 == 1 ) {
											echo "<th colspan=2 style=vertical-align:middle;> </th>";
										}
									}
									$j++;
								}
								echo "</tr>";
								echo "<tr>";
								echo "<th><strong>Point</strong></th>";
								$j=1;
								while ( $j < $c1 ) {
									echo "<th> </th>";
									$j++;
								}
								echo "</tr>";
							}
							$i++;
						}
						?>
						</table>
						<br><br>
					</fieldset>

				<?php
				}
				?>
				<?php
				$ct=count($tabj);
				if ( $ct > 0 ) {
					$i=0;
					$tb=[];
					while ( $i<$ct ) {
						$nm=strval($tabj[$i][1]);
						if (isset($tb[$nm])) {
							$tb[$nm]++;
						} else {
							$tb[$nm]=1;
						}
						$i++;
					}
				?>
					<fieldset>
						<legend>Nombre de joueurs par nombre de matchs</legend>
						<table>
						<?php
						$cm=array_keys($tb);
						$i=0;
						$c=count($cm);
						echo "<tr>";
						echo "<th>Nombre de matchs</th>";
						echo "<th>Nombre de joueurs</th>";
						echo "</tr>";
						while ( $i < $c) {
							echo "<tr>";
							echo "<th>".$cm[$i]."</th>";
							echo "<th>".$tb[$cm[$i]]."</th>";
							echo "</tr>";
							$i++;
						}
						?>
						</table>
						<br><br>
					</fieldset>
					<?php
					$i=0;
					while ( $i < $c) {
					?>
					<fieldset>
					<legend>Liste des joueurs ayant joué <?php echo $cm[$i] ?> match(s)</legend>
						<table>
						<?php
						$j=0;
						$c1=count($tabj);
						while ( $j < $c1 ) {
							if ($tabj[$j][1] == $cm[$i]) {
								echo "<tr>";
								echo "<th>".$tabj[$j][0]."</th>";
								echo "</tr>";
							}
							$j++;
						}
						?>
						</table>
						<br><br>
					</fieldset>
					<?php
						$i++;
					}
				}
				?>
			</fieldset>
		</form>
		<script>
			// load requirements for declarative widgets in page content
			require(["dojo/parser", "dijit/form/Button"]);
		</script>
	</body>
</html>

