<?php
// This file was auto-generated from sdk-root/src/data/personalize-runtime/2018-05-22/paginators-1.json
return [ 'pagination' => [],];
