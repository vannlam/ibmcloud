<?php
// This file was auto-generated from sdk-root/src/data/sagemaker-a2i-runtime/2019-11-07/paginators-1.json
return [ 'pagination' => [ 'ListHumanLoops' => [ 'input_token' => 'NextToken', 'output_token' => 'NextToken', 'limit_key' => 'MaxResults', 'result_key' => 'HumanLoopSummaries', ], ],];
