<?php
// This file was auto-generated from sdk-root/src/data/payment-cryptography/2021-09-14/waiters-2.json
return [ 'version' => 2, 'waiters' => [],];
