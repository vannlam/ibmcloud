<?php
// This file was auto-generated from sdk-root/src/data/geo-maps/2020-11-19/paginators-1.json
return [ 'pagination' => [],];
