<?php
// This file was auto-generated from sdk-root/src/data/personalize-events/2018-03-22/paginators-1.json
return [ 'pagination' => [],];
